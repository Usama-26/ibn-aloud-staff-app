import AppLayout from "@/layouts/AppLayout";

export default function Dashboard() {
  return <AppLayout></AppLayout>;
}
