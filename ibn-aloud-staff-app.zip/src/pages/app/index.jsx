import AppLayout from "@/layouts/AppLayout";

export default function MainApp() {
  return <AppLayout></AppLayout>;
}
